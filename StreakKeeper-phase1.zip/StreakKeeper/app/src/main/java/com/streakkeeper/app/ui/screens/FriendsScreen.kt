package com.streakkeeper.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.streakkeeper.app.R

// Phase 2: list from FriendDao.observeAll(), add/edit/delete dialog, sticker picker.
@Composable
fun FriendsScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = stringResource(R.string.friends_title),
            style = MaterialTheme.typography.headlineMedium
        )
    }
}
