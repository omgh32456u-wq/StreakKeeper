package com.streakkeeper.app

import android.app.Application
import com.streakkeeper.app.data.AppDatabase

class StreakKeeperApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.get(this) }
}
