package com.streakkeeper.app.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.streakkeeper.app.R

sealed class Screen(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector
) {
    data object Dashboard : Screen("dashboard", R.string.nav_dashboard, Icons.Filled.Home)
    data object Friends : Screen("friends", R.string.nav_friends, Icons.Filled.Person)
    data object Settings : Screen("settings", R.string.nav_settings, Icons.Filled.Settings)
}

val bottomDestinations: List<Screen> = listOf(Screen.Dashboard, Screen.Friends, Screen.Settings)
