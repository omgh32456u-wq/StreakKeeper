# Streak Keeper — Phase 1

Kotlin + Jetpack Compose + Material 3 + Room + WorkManager. Package: `com.streakkeeper.app`.
Arabic default (forced RTL), dark-first. Phase 1 = architecture, Gradle, theme, navigation, Room `Friend` entity.

## Requirements

- JDK 17
- Android SDK with platform 35 (Android Studio Ladybug or newer recommended)
- minSdk 26, compileSdk/targetSdk 35
- Versions: AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Gradle 8.9, Compose BOM 2024.12.01, Room 2.6.1, WorkManager 2.10.0

## Build

The Gradle wrapper jar and `gradlew` scripts are not included. Generate them once:

```
gradle wrapper --gradle-version 8.9
```

Or open the project in Android Studio, which generates them on sync.

Then:

```
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Install on a connected device or emulator:

```
./gradlew installDebug
```

If the SDK is not found, create `local.properties` with `sdk.dir=/path/to/Android/Sdk`.

## Structure

```
app/src/main/java/com/streakkeeper/app/
  StreakKeeperApp.kt        Application, lazy Room database
  MainActivity.kt           edge-to-edge, theme, root composable
  data/                     Friend, FriendDao, AppDatabase (v1, schema exported)
  ui/theme/Theme.kt         dark-first Material 3 theme, forced RTL
  ui/navigation/            Screen, StreakKeeperRoot (bottom nav)
  ui/screens/               Dashboard, Friends, Settings
```

## Status

- Friends: entity and DAO only. UI is a placeholder.
- Dashboard: shows the friend count from Room. Send All is disabled until Phase 2.
- Settings: placeholder.
- Auto Reply: not implemented. TikTok exposes no supported API for it.

## Phase 2

- Add `SendTask` entity, bump DB to v2 with `Migration(1, 2)`. Do not alter `Friend`.
- Add `FriendRepository` and `FriendsViewModel`, then replace the `FriendsScreen` body.
- Add `work/DailySendWorker.kt` and a settings store; fill in `SettingsScreen`.
- Wire the Send All button to the queue. A task is marked done only on explicit user confirmation.
